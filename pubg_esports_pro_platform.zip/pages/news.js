
export default function News(){

return (
<div style={{background:'#070707',color:'white',minHeight:'100vh',padding:'40px'}}>

<h1>E-Spor Haberleri</h1>

<ul>
<li>PUBG yeni patch</li>
<li>Yeni turnuvalar</li>
<li>Takım transferleri</li>
</ul>

</div>
)
}
