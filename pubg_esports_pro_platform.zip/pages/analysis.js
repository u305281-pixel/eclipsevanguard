
export default function Analysis(){

return (
<div style={{background:'#070707',color:'white',minHeight:'100vh',padding:'40px'}}>

<h1>AI Oyuncu Analizi</h1>

<p>AI analiz:</p>

<ul>
<li>En iyi oynanan gün</li>
<li>En kötü performans günü</li>
<li>Kill ortalaması</li>
<li>Turnuva performansı</li>
</ul>

</div>
)
}
