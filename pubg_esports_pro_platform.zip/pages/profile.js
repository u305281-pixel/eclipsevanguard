
export default function Profile(){

return (
<div style={{background:'#070707',color:'white',minHeight:'100vh',padding:'40px'}}>

<h1>Oyuncu Profili</h1>

<p>PUBG hesabını bağla</p>

<ul>
<li>KD Oranı</li>
<li>Toplam Kill</li>
<li>Maç Sayısı</li>
<li>Son Performans</li>
<li>Kazanılan Tavuk</li>
</ul>

</div>
)
}
