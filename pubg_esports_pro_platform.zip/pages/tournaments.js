
export default function Tournaments(){

return (
<div style={{background:'#070707',color:'white',minHeight:'100vh',padding:'40px'}}>

<h1>PUBG Turnuvaları</h1>

<ul>
<li>Pro League</li>
<li>Weekly Scrim</li>
<li>Battle Royale Cup</li>
</ul>

</div>
)
}
