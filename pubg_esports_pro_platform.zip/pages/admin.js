
export default function Admin(){

return (
<div style={{background:'#070707',color:'white',minHeight:'100vh',padding:'40px'}}>

<h1>Admin Panel</h1>

<ul>
<li>Turnuva oluştur</li>
<li>Skor güncelle</li>
<li>Oyuncu ban</li>
<li>Haber ekle</li>
</ul>

</div>
)
}
