
export default function Maps(){

return (
<div style={{background:'#070707',color:'white',minHeight:'100vh',padding:'40px'}}>

<h1>Harita Performansı</h1>

<ul>
<li>Erangel</li>
<li>Miramar</li>
<li>Sanhok</li>
<li>Livik</li>
<li>Vikendi</li>
</ul>

</div>
)
}
