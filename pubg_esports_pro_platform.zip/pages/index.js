
import Link from 'next/link'

export default function Home(){
return (
<div style={{background:'#070707',color:'white',minHeight:'100vh',padding:'40px'}}>

<h1>PUBG Esports Platform</h1>
<p>Profesyonel PUBG oyuncu analiz ve turnuva sistemi</p>

<ul style={{lineHeight:'2',marginTop:30}}>
<li><Link href="/profile">Oyuncu Profili</Link></li>
<li><Link href="/maps">Harita Analizi</Link></li>
<li><Link href="/analysis">AI Performans Analizi</Link></li>
<li><Link href="/tournaments">Turnuvalar</Link></li>
<li><Link href="/news">E-Spor Haberleri</Link></li>
<li><Link href="/admin">Admin Panel</Link></li>
</ul>

</div>
)
}
