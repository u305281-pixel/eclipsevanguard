
export function analyzePlayer(matches){

return {
bestDay:"Saturday",
worstDay:"Monday",
averageKills:4.3
}

}
