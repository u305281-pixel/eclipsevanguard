
export async function getPlayerStats(playerName){

const API_KEY = "PUT_PUBG_API_KEY"

const response = await fetch(
`https://api.pubg.com/shards/steam/players?filter[playerNames]=${playerName}`,
{
headers:{
Authorization:`Bearer ${API_KEY}`,
Accept:"application/vnd.api+json"
}
})

const data = await response.json()

return data

}
