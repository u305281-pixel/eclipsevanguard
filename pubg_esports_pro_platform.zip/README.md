
# PUBG Esports PRO Platform

Profesyonel PUBG e-spor platformu için gelişmiş başlangıç projesi.

## Özellikler

- Oyuncu profil sistemi
- PUBG hesap bağlama
- KD / kill / maç istatistikleri
- En çok oynanan harita analizi
- AI oyuncu performans analizi
- Turnuva sistemi
- Bracket sistemi
- AI e-spor haberleri
- Güvenli giriş sistemi
- Admin panel
- Otomatik güncelleme altyapısı

## Teknoloji

Frontend:
Next.js + React

Backend:
Next.js API Routes

Auth:
Firebase Auth

Database:
Firebase / Supabase

PUBG API:
https://developer.pubg.com

AI:
OpenAI API

## Kurulum

Node.js kur

Terminal:

npm install
npm run dev

## Klasör Yapısı

components/
pages/
services/
api/
styles/

